package callback;

public class Testface
{
	public static void main(String[] args)
	{
		Callback c = new Client();
		c.callback(42);
	}

}
