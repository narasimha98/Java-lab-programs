package callback;

public interface Callback
{
	void callback(int param);

}
